package com.pesspringdemo.springappdemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringappdemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
